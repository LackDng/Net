"""
NetAnalyzer - AI Config Analyzer v2
3 bước phân tích rõ ràng:
  1. Đúng   — cấu hình đã tốt, không cần thay đổi
  2. Sai    — cấu hình nguy hiểm, thiếu, hoặc không đúng best practice
  3. Dư     — cấu hình không cần thiết, nên xóa
  + Đề xuất — lệnh cụ thể để sửa từng vấn đề
"""

import os
import json
import re
import logging
from dataclasses import dataclass, field
from typing import Optional, List

logger = logging.getLogger(__name__)


# ── Data structures ────────────────────────────────────────────────────────────

@dataclass
class Finding:
    """Một vấn đề tìm thấy trong config."""
    severity: str       # critical | warning | info
    category: str       # security | performance | stability | compliance
    status: str         # correct | wrong | redundant
    title: str
    description: str
    recommendation: str
    commands: List[str] = field(default_factory=list)
    cis_reference: str = ""


@dataclass
class ConfigRecommendation:
    """Một đề xuất thay đổi config cụ thể."""
    priority: str           # high | medium | low
    action: str             # add | remove | change
    reason: str
    config_lines: List[str] = field(default_factory=list)   # Lệnh cần THÊM/SỬA
    remove_lines: List[str] = field(default_factory=list)   # Lệnh cần XÓA


@dataclass
class AnalysisResult:
    hostname: str
    ip: str
    vendor: str
    score: int
    grade: str
    summary: str
    findings: List[Finding] = field(default_factory=list)
    recommendations: List[ConfigRecommendation] = field(default_factory=list)
    score_breakdown: dict = field(default_factory=dict)
    raw_ai_response: str = ""
    error: Optional[str] = None

    @property
    def correct_findings(self):
        return [f for f in self.findings if f.status == "correct"]

    @property
    def wrong_findings(self):
        return [f for f in self.findings if f.status == "wrong"]

    @property
    def redundant_findings(self):
        return [f for f in self.findings if f.status == "redundant"]


# ── System Prompt ──────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """Bạn là chuyên gia bảo mật và tối ưu hóa mạng với 20 năm kinh nghiệm về Cisco IOS/IOS-XE/NX-OS, MikroTik RouterOS, Juniper JunOS, HP/Aruba.

Nhiệm vụ: Phân tích TOÀN BỘ cấu hình thiết bị mạng theo 3 nhóm rõ ràng:

1. **ĐÚNG (correct)** — Cấu hình đã tốt, đúng best practice, không cần thay đổi
2. **SAI (wrong)** — Cấu hình nguy hiểm, thiếu, hoặc không đúng best practice  
3. **DƯ (redundant)** — Cấu hình thừa, không cần thiết, hoặc nên xóa bỏ

Sau đó đưa ra **ĐỀ XUẤT CỤ THỂ**: lệnh cần thêm, sửa, và xóa.

---

QUAN TRỌNG: Trả lời CHÍNH XÁC theo JSON schema sau, KHÔNG thêm bất kỳ text nào ngoài JSON:

{
  "score": <int 0-100>,
  "grade": "<A|B|C|D|F>",
  "summary": "<tóm tắt ngắn bằng tiếng Việt: thiết bị này đang ở tình trạng thế nào>",
  "score_breakdown": {
    "security": <int 0-100>,
    "performance": <int 0-100>,
    "stability": <int 0-100>,
    "compliance": <int 0-100>
  },
  "findings": [
    {
      "status": "correct",
      "severity": "info",
      "category": "<security|performance|stability|compliance>",
      "title": "<tên ngắn gọn>",
      "description": "<mô tả tại sao cấu hình này đúng/tốt>",
      "recommendation": "Giữ nguyên",
      "commands": [],
      "cis_reference": ""
    },
    {
      "status": "wrong",
      "severity": "<critical|warning|info>",
      "category": "<security|performance|stability|compliance>",
      "title": "<tên ngắn gọn>",
      "description": "<mô tả vấn đề cụ thể, tại sao sai, rủi ro là gì>",
      "recommendation": "<giải thích cần làm gì>",
      "commands": ["<lệnh cụ thể để sửa>", "..."],
      "cis_reference": "<CIS Control nếu có>"
    },
    {
      "status": "redundant",
      "severity": "warning",
      "category": "<security|performance|stability|compliance>",
      "title": "<tên ngắn gọn>",
      "description": "<mô tả tại sao cấu hình này dư/không cần thiết>",
      "recommendation": "<giải thích nên xóa/tắt như thế nào>",
      "commands": ["<lệnh để xóa/tắt>"],
      "cis_reference": ""
    }
  ],
  "recommendations": [
    {
      "priority": "<high|medium|low>",
      "action": "<add|remove|change>",
      "reason": "<lý do ngắn gọn bằng tiếng Việt>",
      "config_lines": ["<lệnh cần THÊM hoặc SỬA vào thiết bị>"],
      "remove_lines": ["<lệnh hoặc config cần XÓA khỏi thiết bị>"]
    }
  ]
}

---

Quy tắc chấm điểm:
- Mỗi critical wrong: -15 đến -20 điểm
- Mỗi warning wrong: -5 đến -10 điểm  
- Mỗi redundant: -2 đến -5 điểm
- Score 90-100=A (xuất sắc), 80-89=B (tốt), 70-79=C (trung bình), 60-69=D (kém), <60=F (nguy hiểm)

Checklist bắt buộc kiểm tra:

SECURITY:
- [ ] Telnet enabled trên VTY (critical wrong)
- [ ] enable password thay vì enable secret (critical wrong)
- [ ] SSH version 1 (critical wrong)
- [ ] SNMP community là "public" hoặc "private" (critical wrong)
- [ ] HTTP server còn bật - ip http server (critical wrong)
- [ ] Không có service password-encryption (warning wrong)
- [ ] Không có login failure logging (warning wrong)
- [ ] Không có exec-timeout trên VTY (warning wrong)
- [ ] Không có banner motd hoặc banner login (info wrong)
- [ ] AAA không được cấu hình (warning wrong)
- [ ] CDP/LLDP bật trên uplink ra ngoài (warning wrong - lộ topology)

PERFORMANCE:
- [ ] Interface duplex/speed không cố định (warning wrong)
- [ ] Không có QoS trên WAN interface (info wrong)
- [ ] Routing protocol chưa tối ưu (info wrong)
- [ ] MTU chưa được tối ưu (info wrong)

STABILITY:
- [ ] Không có NTP server (warning wrong)
- [ ] Không có syslog server (warning wrong)
- [ ] STP không có BPDU Guard trên access ports (warning wrong)
- [ ] STP không có Root Guard (warning wrong)
- [ ] Không có HSRP/VRRP trên core router (info wrong)
- [ ] Không có IP SLA monitoring (info wrong)

REDUNDANT (dư thừa):
- [ ] service tcp-small-servers (redundant - nên xóa)
- [ ] service udp-small-servers (redundant - nên xóa)
- [ ] ip finger (redundant)
- [ ] ip bootp server (redundant)
- [ ] ip http server khi không dùng web UI (redundant)
- [ ] unused interface không được shutdown và không có description (redundant)
- [ ] Cấu hình default route trùng lặp (redundant)
- [ ] ACL không được apply vào interface nào (redundant)
"""


# ── Analyzer ───────────────────────────────────────────────────────────────────

class AIConfigAnalyzer:
    def __init__(self, api_key=None, model="claude-sonnet-4-20250514"):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.model = model

    def analyze(self, device_config) -> AnalysisResult:
        result = AnalysisResult(
            hostname=device_config.hostname,
            ip=device_config.ip,
            vendor=device_config.vendor,
            score=0, grade="F",
            summary="Chưa phân tích",
        )

        if not self.api_key:
            result.error = "Thiếu ANTHROPIC_API_KEY — vào Cài đặt để nhập key"
            return result

        if device_config.error:
            result.error = f"Lỗi kết nối: {device_config.error}"
            return result

        try:
            import anthropic
            import httpx

            http_client = httpx.Client(timeout=120.0)
            try:
                client = anthropic.Anthropic(api_key=self.api_key, http_client=http_client)
            except TypeError:
                client = anthropic.Anthropic(api_key=self.api_key)

            user_message = self._build_prompt(device_config)
            logger.info(f"[AI] Phân tích {device_config.hostname} ({len(user_message)} chars)...")

            response = client.messages.create(
                model=self.model,
                max_tokens=8096,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_message}],
            )
            raw = response.content[0].text
            result.raw_ai_response = raw
            self._parse_response(raw, result)

            logger.info(
                f"[AI] {device_config.hostname}: {result.score}/100 ({result.grade}) | "
                f"correct={len(result.correct_findings)} wrong={len(result.wrong_findings)} redundant={len(result.redundant_findings)}"
            )

        except Exception as e:
            result.error = str(e)
            logger.error(f"[AI] Lỗi: {e}")

        return result

    # ── Build prompt ──────────────────────────────────────────────────────────

    def _build_prompt(self, device_config) -> str:
        parts = [
            f"# Phân tích cấu hình thiết bị",
            f"Hostname: {device_config.hostname}",
            f"IP: {device_config.ip}",
            f"Vendor/OS: {device_config.vendor} / {device_config.device_type}",
            "",
        ]

        if device_config.running_config:
            parts += [
                "## Running Configuration (đầy đủ)",
                "```",
                device_config.running_config[:10000],
                "```\n",
            ]

        # Thêm các output bổ sung quan trọng
        extra_cmds = [
            "show version",
            "show interfaces",
            "show spanning-tree",
            "show ntp status",
            "show snmp",
            "show logging",
            "show access-lists",
            "show ip route",
            "/ip service print",
            "/user print",
            "/snmp print",
            "/ip firewall filter print",
            "show configuration",
        ]
        for cmd in extra_cmds:
            if cmd in device_config.raw_configs:
                out = device_config.raw_configs[cmd]
                if out and "[ERROR" not in out and len(out.strip()) > 10:
                    parts += [f"## Output: {cmd}", "```", out[:3000], "```\n"]

        parts.append(
            "Hãy phân tích TOÀN BỘ config trên theo 3 nhóm: correct / wrong / redundant "
            "và đưa ra recommendations cụ thể. Trả về JSON theo đúng format."
        )
        return "\n".join(parts)

    # ── Parse response ─────────────────────────────────────────────────────────

    def _parse_response(self, raw: str, result: AnalysisResult):
        text = raw.strip()

        # Strip markdown code blocks
        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
        if m:
            text = m.group(1).strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            m = re.search(r"\{[\s\S]*\}", text)
            if not m:
                result.error = "AI trả về format không hợp lệ"
                return
            try:
                data = json.loads(m.group())
            except Exception:
                result.error = "Không parse được JSON"
                return

        result.score = int(data.get("score", 0))
        result.grade = data.get("grade", "F")
        result.summary = data.get("summary", "")
        result.score_breakdown = data.get("score_breakdown", {})

        # Parse findings
        for f in data.get("findings", []):
            result.findings.append(Finding(
                status=f.get("status", "wrong"),
                severity=f.get("severity", "info"),
                category=f.get("category", "security"),
                title=f.get("title", ""),
                description=f.get("description", ""),
                recommendation=f.get("recommendation", ""),
                commands=f.get("commands", []),
                cis_reference=f.get("cis_reference", ""),
            ))

        # Parse recommendations
        for r in data.get("recommendations", []):
            result.recommendations.append(ConfigRecommendation(
                priority=r.get("priority", "medium"),
                action=r.get("action", "change"),
                reason=r.get("reason", ""),
                config_lines=r.get("config_lines", []),
                remove_lines=r.get("remove_lines", []),
            ))


# ── Report generator ───────────────────────────────────────────────────────────

def generate_text_report(result: AnalysisResult, snapshot_time: str = "") -> str:
    """Tạo báo cáo dạng text đầy đủ để export."""
    SEP = "=" * 60
    sep = "-" * 60
    lines = [
        SEP,
        "  NETANALYZER - BÁO CÁO PHÂN TÍCH CẤU HÌNH MẠNG",
        SEP,
        f"  Thiết bị  : {result.hostname}",
        f"  IP        : {result.ip}",
        f"  Vendor    : {result.vendor}",
        f"  Thời gian : {snapshot_time}",
        f"  Điểm      : {result.score}/100  (Grade: {result.grade})",
        sep,
        f"  Tóm tắt   : {result.summary}",
        SEP,
        "",
    ]

    # Score breakdown
    lines += ["[ ĐIỂM CHI TIẾT ]", ""]
    for cat, val in result.score_breakdown.items():
        bar = "█" * (val // 5) + "░" * (20 - val // 5)
        lines.append(f"  {cat.upper():<12} {bar} {val}/100")
    lines += ["", SEP, ""]

    # ── ĐÚNG ──
    correct = result.correct_findings
    lines += [f"[ ✅ CẤU HÌNH ĐÚNG / TỐT — {len(correct)} mục ]", ""]
    if correct:
        for f in correct:
            lines += [
                f"  ✅ [{f.category.upper()}] {f.title}",
                f"     {f.description}",
                "",
            ]
    else:
        lines += ["  (Không có mục nào được đánh giá đúng)", ""]

    lines += [sep, ""]

    # ── SAI ──
    wrong = sorted(result.wrong_findings,
                   key=lambda x: {"critical": 0, "warning": 1, "info": 2}[x.severity])
    lines += [f"[ ❌ CẤU HÌNH SAI / THIẾU — {len(wrong)} mục ]", ""]
    if wrong:
        for f in wrong:
            icon = "🔴" if f.severity == "critical" else "🟡" if f.severity == "warning" else "🔵"
            lines += [
                f"  {icon} [{f.severity.upper()}] [{f.category.upper()}] {f.title}",
                f"     Vấn đề     : {f.description}",
                f"     Khuyến nghị: {f.recommendation}",
            ]
            if f.commands:
                lines.append("     Lệnh sửa   :")
                for cmd in f.commands:
                    lines.append(f"       > {cmd}")
            if f.cis_reference:
                lines.append(f"     CIS Ref    : {f.cis_reference}")
            lines.append("")
    else:
        lines += ["  (Không tìm thấy vấn đề)", ""]

    lines += [sep, ""]

    # ── DƯ ──
    redundant = result.redundant_findings
    lines += [f"[ ⚠️  CẤU HÌNH DƯ / NÊN XÓA — {len(redundant)} mục ]", ""]
    if redundant:
        for f in redundant:
            lines += [
                f"  ⚠️  [{f.category.upper()}] {f.title}",
                f"     Lý do      : {f.description}",
                f"     Cách xử lý : {f.recommendation}",
            ]
            if f.commands:
                lines.append("     Lệnh xóa   :")
                for cmd in f.commands:
                    lines.append(f"       > {cmd}")
            lines.append("")
    else:
        lines += ["  (Không có cấu hình dư thừa)", ""]

    lines += [SEP, ""]

    # ── ĐỀ XUẤT ──
    recs_high = [r for r in result.recommendations if r.priority == "high"]
    recs_med  = [r for r in result.recommendations if r.priority == "medium"]
    recs_low  = [r for r in result.recommendations if r.priority == "low"]

    lines += [f"[ 📋 ĐỀ XUẤT THAY ĐỔI CẤU HÌNH — {len(result.recommendations)} mục ]", ""]

    for priority_label, recs in [("🔴 ƯU TIÊN CAO", recs_high),
                                   ("🟡 ƯU TIÊN TRUNG BÌNH", recs_med),
                                   ("🔵 ƯU TIÊN THẤP", recs_low)]:
        if not recs:
            continue
        lines += [f"  {priority_label}:", ""]
        for i, r in enumerate(recs, 1):
            lines += [f"  [{i}] {r.reason}"]
            if r.config_lines:
                lines.append("      -- Thêm/Sửa các dòng sau:")
                for line in r.config_lines:
                    lines.append(f"         {line}")
            if r.remove_lines:
                lines.append("      -- Xóa các dòng sau:")
                for line in r.remove_lines:
                    lines.append(f"         no {line}")
            lines.append("")

    lines += [SEP,
              "  Báo cáo tạo bởi NetAnalyzer — AI-powered Network Config Analyzer",
              SEP]

    return "\n".join(lines)


def analyze_from_text(config_text, hostname="device", vendor="cisco_ios", api_key=None):
    """Phân tích từ text config, không cần kết nối thiết bị."""
    from core.connector import DeviceConfig
    mock = DeviceConfig(
        hostname=hostname, ip="0.0.0.0",
        vendor=vendor, device_type=vendor,
        running_config=config_text, connected=True,
    )
    return AIConfigAnalyzer(api_key=api_key).analyze(mock)
