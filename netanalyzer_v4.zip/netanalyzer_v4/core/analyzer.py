"""
NetAnalyzer - AI Config Analyzer v2
Gồm 2 chức năng AI chính:
  A. identify_device_with_ai() — nhận diện vendor/model/commands từ probe output
  B. AIConfigAnalyzer.analyze() — phân tích config: đúng / sai / dư + đề xuất
"""

import os
import json
import re
import logging
from dataclasses import dataclass, field
from typing import Optional, List

logger = logging.getLogger(__name__)


# ── A. AI Device Identification ────────────────────────────────────────────────

IDENTIFY_SYSTEM_PROMPT = """Bạn là chuyên gia mạng với 20 năm kinh nghiệm về tất cả các hãng thiết bị mạng.

Dựa vào SSH probe output (banner + output của các lệnh thử), hãy xác định CHÍNH XÁC:
1. Vendor (hãng): cisco, mikrotik, juniper, hp, huawei, aruba, fortigate, paloalto, ubiquiti, ...
2. Model cụ thể: (Catalyst 2960, Catalyst 9300, CCR1036, CCR2004, RB3011, MX480, SRX300, ...)
3. OS và version: (IOS 15.x, IOS-XE 17.x, NX-OS 9.x, RouterOS 6.x, RouterOS 7.x, JunOS 21.x, ...)
4. netmiko_device_type chính xác: cisco_ios / cisco_nxos / cisco_xr / cisco_asa / mikrotik_routeros / juniper_junos / hp_comware / hp_procurve / aruba_os / huawei_vrpv8 / ...
5. Danh sách lệnh CHÍNH XÁC và ĐẦY ĐỦ để đọc toàn bộ cấu hình của model + OS version đó

QUAN TRỌNG về commands theo vendor:
- Cisco IOS/IOS-XE: show running-config, show version, show interfaces, show ip interface brief, show spanning-tree, show vlan brief, show ip route, show logging, show ntp status, show snmp, show access-lists, show crypto key mypubkey rsa, show cdp neighbors detail
  + Nếu IOS-XE 17.x thêm: show platform, show wireless summary (nếu WLC)
  + Nếu có BGP thêm: show bgp summary, show bgp neighbors
  + Nếu có MPLS thêm: show mpls interfaces, show mpls ldp neighbor
- Cisco NX-OS: show running-config, show version, show interface brief, show vlan brief, show spanning-tree, show ip route, show ntp peers, show snmp, show logging, show cdp neighbors detail, show feature, show vpc, show port-channel summary
- Cisco ASA: show running-config, show version, show interface, show route, show nat, show access-list, show crypto ikev1 sa, show vpn-sessiondb summary, show logging
- Cisco IOS-XR: show running-config, show version, show interfaces, show ip route summary, show bgp summary, show mpls interfaces, show logging
- MikroTik RouterOS 6.x: /export, /system identity print, /system resource print, /interface print detail, /ip address print, /ip firewall filter print, /ip firewall nat print, /ip firewall mangle print, /system ntp client print, /snmp print, /user print, /ip service print, /system logging print, /certificate print
- MikroTik RouterOS 7.x: thêm /interface/bridge/port print, /routing/ospf/instance print, /routing/bgp/peer print
- Juniper JunOS: show configuration, show version, show interfaces terse, show route summary, show spanning-tree interface, show ntp associations, show snmp, show log messages | last 50, show bgp summary
- HP Comware/H3C: display current-configuration, display version, display interface brief, display vlan all, display stp, display ntp status, display snmp-agent sys-info, display logbuffer, display bgp peer
- Huawei VRP: display current-configuration, display version, display interface brief, display vlan, display stp, display ntp status, display snmp-agent sys-info, display logbuffer
- Aruba/HP ProCurve: show running-config, show version, show interfaces, show vlan, show spanning-tree, show ntp, show snmp-server, show logging

Trả về JSON (KHÔNG có text ngoài JSON):
{
  "vendor": "<tên hãng chữ thường, ví dụ: cisco, mikrotik, juniper>",
  "model": "<model cụ thể, ví dụ: Catalyst 3850-24T>",
  "os_version": "<OS và version, ví dụ: IOS-XE 16.9.4>",
  "netmiko_device_type": "<loại netmiko chính xác>",
  "confidence": "high|medium|low",
  "commands": ["<lệnh 1>", "<lệnh 2>", "..."],
  "reason": "<giải thích ngắn tại sao nhận diện như vậy, dẫn chứng từ output>"
}
"""


def identify_device_with_ai(
    probe_text: str,
    api_key: str,
    vendor_override: str = "",
    model_override: str = "",
) -> "DeviceIdentity":
    """
    Gọi Claude Haiku để nhận diện vendor/model/OS/commands từ probe output.
    Nếu user cung cấp vendor_override hoặc model_override, AI sẽ dùng làm gợi ý
    nhưng vẫn tự xác định commands phù hợp.

    Returns: DeviceIdentity
    """
    from core.connector import DeviceIdentity, FALLBACK_COMMANDS

    identity = DeviceIdentity()

    if not api_key:
        identity.detected_by = "fallback"
        identity.vendor = "cisco"
        identity.netmiko_device_type = "cisco_ios"
        identity.commands = FALLBACK_COMMANDS["cisco_ios"]
        identity.confidence = "low"
        identity.reason = "Không có API key — dùng Cisco IOS fallback"
        return identity

    try:
        import anthropic

        client = anthropic.Anthropic(api_key=api_key)

        user_msg = f"SSH Probe Output:\n\n{probe_text}"

        if vendor_override or model_override:
            user_msg += (
                f"\n\n[User Override] Vendor: {vendor_override or 'auto'}, "
                f"Model: {model_override or 'auto'}\n"
                "Hãy ưu tiên thông tin user cung cấp khi xác định vendor/model, "
                "nhưng vẫn tự xác định OS version và commands chính xác."
            )

        response = client.messages.create(
            model="claude-haiku-4-5-20251001",   # Haiku: nhanh + rẻ cho bước identify
            max_tokens=1024,
            system=IDENTIFY_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
        )

        raw = response.content[0].text.strip()
        logger.debug(f"[AI Identify] raw response: {raw[:200]}")

        # Parse JSON
        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw)
        text = m.group(1).strip() if m else raw
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            m2 = re.search(r"\{[\s\S]*\}", text)
            data = json.loads(m2.group()) if m2 else {}

        identity.vendor              = data.get("vendor", "unknown")
        identity.model               = data.get("model", "unknown")
        identity.os_version          = data.get("os_version", "")
        identity.netmiko_device_type = data.get("netmiko_device_type", "cisco_ios")
        identity.commands            = data.get("commands", [])
        identity.confidence          = data.get("confidence", "medium")
        identity.reason              = data.get("reason", "")
        identity.detected_by = (
            "manual_override" if (vendor_override or model_override) else "ai"
        )

        # Nếu AI không trả về commands, dùng fallback
        if not identity.commands:
            dt = identity.netmiko_device_type
            identity.commands = FALLBACK_COMMANDS.get(dt, FALLBACK_COMMANDS["cisco_ios"])
            logger.warning(f"[AI Identify] Không có commands trong response, dùng fallback {dt}")

        logger.info(
            f"[AI Identify] {identity.vendor} {identity.model} "
            f"({identity.os_version}) confidence={identity.confidence}"
        )

    except Exception as e:
        logger.error(f"[AI Identify] Error: {e}")
        identity.detected_by = "fallback"
        identity.vendor = "cisco"
        identity.netmiko_device_type = "cisco_ios"
        identity.commands = FALLBACK_COMMANDS["cisco_ios"]
        identity.confidence = "low"
        identity.reason = f"AI error: {e}"

    return identity


# ── Data structures ────────────────────────────────────────────────────────────

@dataclass
class Finding:
    """Một vấn đề tìm thấy trong config."""
    severity: str       # critical | warning | info
    category: str       # security | performance | stability | compliance
    status: str         # correct | wrong | redundant
    title: str
    description: str
    recommendation: str
    commands: List[str] = field(default_factory=list)
    cis_reference: str = ""


@dataclass
class ConfigRecommendation:
    """Một đề xuất thay đổi config cụ thể."""
    priority: str           # high | medium | low
    action: str             # add | remove | change
    reason: str
    config_lines: List[str] = field(default_factory=list)   # Lệnh cần THÊM/SỬA
    remove_lines: List[str] = field(default_factory=list)   # Lệnh cần XÓA


@dataclass
class AnalysisResult:
    hostname: str
    ip: str
    vendor: str
    score: int
    grade: str
    summary: str
    findings: List[Finding] = field(default_factory=list)
    recommendations: List[ConfigRecommendation] = field(default_factory=list)
    score_breakdown: dict = field(default_factory=dict)
    raw_ai_response: str = ""
    error: Optional[str] = None

    @property
    def correct_findings(self):
        return [f for f in self.findings if f.status == "correct"]

    @property
    def wrong_findings(self):
        return [f for f in self.findings if f.status == "wrong"]

    @property
    def redundant_findings(self):
        return [f for f in self.findings if f.status == "redundant"]


# ── System Prompt ──────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """Bạn là chuyên gia bảo mật và tối ưu hóa mạng với 20 năm kinh nghiệm về Cisco IOS/IOS-XE/NX-OS, MikroTik RouterOS, Juniper JunOS, HP/Aruba.

Nhiệm vụ: Phân tích TOÀN BỘ cấu hình thiết bị mạng theo 3 nhóm rõ ràng:

1. **ĐÚNG (correct)** — Cấu hình đã tốt, đúng best practice, không cần thay đổi
2. **SAI (wrong)** — Cấu hình nguy hiểm, thiếu, hoặc không đúng best practice  
3. **DƯ (redundant)** — Cấu hình thừa, không cần thiết, hoặc nên xóa bỏ

Sau đó đưa ra **ĐỀ XUẤT CỤ THỂ**: lệnh cần thêm, sửa, và xóa.

---

QUAN TRỌNG: Trả lời CHÍNH XÁC theo JSON schema sau, KHÔNG thêm bất kỳ text nào ngoài JSON:

{
  "score": <int 0-100>,
  "grade": "<A|B|C|D|F>",
  "summary": "<tóm tắt ngắn bằng tiếng Việt: thiết bị này đang ở tình trạng thế nào>",
  "score_breakdown": {
    "security": <int 0-100>,
    "performance": <int 0-100>,
    "stability": <int 0-100>,
    "compliance": <int 0-100>
  },
  "findings": [
    {
      "status": "correct",
      "severity": "info",
      "category": "<security|performance|stability|compliance>",
      "title": "<tên ngắn gọn>",
      "description": "<mô tả tại sao cấu hình này đúng/tốt>",
      "recommendation": "Giữ nguyên",
      "commands": [],
      "cis_reference": ""
    },
    {
      "status": "wrong",
      "severity": "<critical|warning|info>",
      "category": "<security|performance|stability|compliance>",
      "title": "<tên ngắn gọn>",
      "description": "<mô tả vấn đề cụ thể, tại sao sai, rủi ro là gì>",
      "recommendation": "<giải thích cần làm gì>",
      "commands": ["<lệnh cụ thể để sửa>", "..."],
      "cis_reference": "<CIS Control nếu có>"
    },
    {
      "status": "redundant",
      "severity": "warning",
      "category": "<security|performance|stability|compliance>",
      "title": "<tên ngắn gọn>",
      "description": "<mô tả tại sao cấu hình này dư/không cần thiết>",
      "recommendation": "<giải thích nên xóa/tắt như thế nào>",
      "commands": ["<lệnh để xóa/tắt>"],
      "cis_reference": ""
    }
  ],
  "recommendations": [
    {
      "priority": "<high|medium|low>",
      "action": "<add|remove|change>",
      "reason": "<lý do ngắn gọn bằng tiếng Việt>",
      "config_lines": ["<lệnh cần THÊM hoặc SỬA vào thiết bị>"],
      "remove_lines": ["<lệnh hoặc config cần XÓA khỏi thiết bị>"]
    }
  ]
}

---

Quy tắc chấm điểm:
- Mỗi critical wrong: -15 đến -20 điểm
- Mỗi warning wrong: -5 đến -10 điểm  
- Mỗi redundant: -2 đến -5 điểm
- Score 90-100=A (xuất sắc), 80-89=B (tốt), 70-79=C (trung bình), 60-69=D (kém), <60=F (nguy hiểm)

Checklist bắt buộc kiểm tra:

SECURITY:
- [ ] Telnet enabled trên VTY (critical wrong)
- [ ] enable password thay vì enable secret (critical wrong)
- [ ] SSH version 1 (critical wrong)
- [ ] SNMP community là "public" hoặc "private" (critical wrong)
- [ ] HTTP server còn bật - ip http server (critical wrong)
- [ ] Không có service password-encryption (warning wrong)
- [ ] Không có login failure logging (warning wrong)
- [ ] Không có exec-timeout trên VTY (warning wrong)
- [ ] Không có banner motd hoặc banner login (info wrong)
- [ ] AAA không được cấu hình (warning wrong)
- [ ] CDP/LLDP bật trên uplink ra ngoài (warning wrong - lộ topology)

PERFORMANCE:
- [ ] Interface duplex/speed không cố định (warning wrong)
- [ ] Không có QoS trên WAN interface (info wrong)
- [ ] Routing protocol chưa tối ưu (info wrong)
- [ ] MTU chưa được tối ưu (info wrong)

STABILITY:
- [ ] Không có NTP server (warning wrong)
- [ ] Không có syslog server (warning wrong)
- [ ] STP không có BPDU Guard trên access ports (warning wrong)
- [ ] STP không có Root Guard (warning wrong)
- [ ] Không có HSRP/VRRP trên core router (info wrong)
- [ ] Không có IP SLA monitoring (info wrong)

REDUNDANT (dư thừa):
- [ ] service tcp-small-servers (redundant - nên xóa)
- [ ] service udp-small-servers (redundant - nên xóa)
- [ ] ip finger (redundant)
- [ ] ip bootp server (redundant)
- [ ] ip http server khi không dùng web UI (redundant)
- [ ] unused interface không được shutdown và không có description (redundant)
- [ ] Cấu hình default route trùng lặp (redundant)
- [ ] ACL không được apply vào interface nào (redundant)
"""


# ── Analyzer ───────────────────────────────────────────────────────────────────

class AIConfigAnalyzer:
    def __init__(self, api_key=None, model="claude-sonnet-4-20250514"):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.model = model

    def analyze(self, device_config) -> AnalysisResult:
        result = AnalysisResult(
            hostname=device_config.hostname,
            ip=device_config.ip,
            vendor=device_config.vendor,
            score=0, grade="F",
            summary="Chưa phân tích",
        )

        if not self.api_key:
            result.error = "Thiếu ANTHROPIC_API_KEY — vào Cài đặt để nhập key"
            return result

        if device_config.error:
            result.error = f"Lỗi kết nối: {device_config.error}"
            return result

        try:
            import anthropic
            import httpx

            http_client = httpx.Client(timeout=120.0)
            try:
                client = anthropic.Anthropic(api_key=self.api_key, http_client=http_client)
            except TypeError:
                client = anthropic.Anthropic(api_key=self.api_key)

            user_message = self._build_prompt(device_config)
            logger.info(f"[AI] Phân tích {device_config.hostname} ({len(user_message)} chars)...")

            response = client.messages.create(
                model=self.model,
                max_tokens=8096,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_message}],
            )
            raw = response.content[0].text
            result.raw_ai_response = raw
            self._parse_response(raw, result)

            logger.info(
                f"[AI] {device_config.hostname}: {result.score}/100 ({result.grade}) | "
                f"correct={len(result.correct_findings)} wrong={len(result.wrong_findings)} redundant={len(result.redundant_findings)}"
            )

        except Exception as e:
            result.error = str(e)
            logger.error(f"[AI] Lỗi: {e}")

        return result

    # ── Build prompt ──────────────────────────────────────────────────────────

    def _build_prompt(self, device_config) -> str:
        parts = [
            f"# Phân tích cấu hình thiết bị",
            f"Hostname: {device_config.hostname}",
            f"IP: {device_config.ip}",
            f"Vendor/OS: {device_config.vendor} / {device_config.device_type}",
            "",
        ]

        if device_config.running_config:
            parts += [
                "## Running Configuration (đầy đủ)",
                "```",
                device_config.running_config[:10000],
                "```\n",
            ]

        # Thêm các output bổ sung quan trọng
        extra_cmds = [
            "show version",
            "show interfaces",
            "show spanning-tree",
            "show ntp status",
            "show snmp",
            "show logging",
            "show access-lists",
            "show ip route",
            "/ip service print",
            "/user print",
            "/snmp print",
            "/ip firewall filter print",
            "show configuration",
        ]
        for cmd in extra_cmds:
            if cmd in device_config.raw_configs:
                out = device_config.raw_configs[cmd]
                if out and "[ERROR" not in out and len(out.strip()) > 10:
                    parts += [f"## Output: {cmd}", "```", out[:3000], "```\n"]

        parts.append(
            "Hãy phân tích TOÀN BỘ config trên theo 3 nhóm: correct / wrong / redundant "
            "và đưa ra recommendations cụ thể. Trả về JSON theo đúng format."
        )
        return "\n".join(parts)

    # ── Parse response ─────────────────────────────────────────────────────────

    def _parse_response(self, raw: str, result: AnalysisResult):
        text = raw.strip()

        # Strip markdown code blocks
        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
        if m:
            text = m.group(1).strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            m = re.search(r"\{[\s\S]*\}", text)
            if not m:
                result.error = "AI trả về format không hợp lệ"
                return
            try:
                data = json.loads(m.group())
            except Exception:
                result.error = "Không parse được JSON"
                return

        result.score = int(data.get("score", 0))
        result.grade = data.get("grade", "F")
        result.summary = data.get("summary", "")
        result.score_breakdown = data.get("score_breakdown", {})

        # Parse findings
        for f in data.get("findings", []):
            result.findings.append(Finding(
                status=f.get("status", "wrong"),
                severity=f.get("severity", "info"),
                category=f.get("category", "security"),
                title=f.get("title", ""),
                description=f.get("description", ""),
                recommendation=f.get("recommendation", ""),
                commands=f.get("commands", []),
                cis_reference=f.get("cis_reference", ""),
            ))

        # Parse recommendations
        for r in data.get("recommendations", []):
            result.recommendations.append(ConfigRecommendation(
                priority=r.get("priority", "medium"),
                action=r.get("action", "change"),
                reason=r.get("reason", ""),
                config_lines=r.get("config_lines", []),
                remove_lines=r.get("remove_lines", []),
            ))


# ── Report generator ───────────────────────────────────────────────────────────

def generate_text_report(result: AnalysisResult, snapshot_time: str = "") -> str:
    """Tạo báo cáo dạng text đầy đủ để export."""
    SEP = "=" * 60
    sep = "-" * 60
    lines = [
        SEP,
        "  NETANALYZER - BÁO CÁO PHÂN TÍCH CẤU HÌNH MẠNG",
        SEP,
        f"  Thiết bị  : {result.hostname}",
        f"  IP        : {result.ip}",
        f"  Vendor    : {result.vendor}",
        f"  Thời gian : {snapshot_time}",
        f"  Điểm      : {result.score}/100  (Grade: {result.grade})",
        sep,
        f"  Tóm tắt   : {result.summary}",
        SEP,
        "",
    ]

    # Score breakdown
    lines += ["[ ĐIỂM CHI TIẾT ]", ""]
    for cat, val in result.score_breakdown.items():
        bar = "█" * (val // 5) + "░" * (20 - val // 5)
        lines.append(f"  {cat.upper():<12} {bar} {val}/100")
    lines += ["", SEP, ""]

    # ── ĐÚNG ──
    correct = result.correct_findings
    lines += [f"[ ✅ CẤU HÌNH ĐÚNG / TỐT — {len(correct)} mục ]", ""]
    if correct:
        for f in correct:
            lines += [
                f"  ✅ [{f.category.upper()}] {f.title}",
                f"     {f.description}",
                "",
            ]
    else:
        lines += ["  (Không có mục nào được đánh giá đúng)", ""]

    lines += [sep, ""]

    # ── SAI ──
    wrong = sorted(result.wrong_findings,
                   key=lambda x: {"critical": 0, "warning": 1, "info": 2}[x.severity])
    lines += [f"[ ❌ CẤU HÌNH SAI / THIẾU — {len(wrong)} mục ]", ""]
    if wrong:
        for f in wrong:
            icon = "🔴" if f.severity == "critical" else "🟡" if f.severity == "warning" else "🔵"
            lines += [
                f"  {icon} [{f.severity.upper()}] [{f.category.upper()}] {f.title}",
                f"     Vấn đề     : {f.description}",
                f"     Khuyến nghị: {f.recommendation}",
            ]
            if f.commands:
                lines.append("     Lệnh sửa   :")
                for cmd in f.commands:
                    lines.append(f"       > {cmd}")
            if f.cis_reference:
                lines.append(f"     CIS Ref    : {f.cis_reference}")
            lines.append("")
    else:
        lines += ["  (Không tìm thấy vấn đề)", ""]

    lines += [sep, ""]

    # ── DƯ ──
    redundant = result.redundant_findings
    lines += [f"[ ⚠️  CẤU HÌNH DƯ / NÊN XÓA — {len(redundant)} mục ]", ""]
    if redundant:
        for f in redundant:
            lines += [
                f"  ⚠️  [{f.category.upper()}] {f.title}",
                f"     Lý do      : {f.description}",
                f"     Cách xử lý : {f.recommendation}",
            ]
            if f.commands:
                lines.append("     Lệnh xóa   :")
                for cmd in f.commands:
                    lines.append(f"       > {cmd}")
            lines.append("")
    else:
        lines += ["  (Không có cấu hình dư thừa)", ""]

    lines += [SEP, ""]

    # ── ĐỀ XUẤT ──
    recs_high = [r for r in result.recommendations if r.priority == "high"]
    recs_med  = [r for r in result.recommendations if r.priority == "medium"]
    recs_low  = [r for r in result.recommendations if r.priority == "low"]

    lines += [f"[ 📋 ĐỀ XUẤT THAY ĐỔI CẤU HÌNH — {len(result.recommendations)} mục ]", ""]

    for priority_label, recs in [("🔴 ƯU TIÊN CAO", recs_high),
                                   ("🟡 ƯU TIÊN TRUNG BÌNH", recs_med),
                                   ("🔵 ƯU TIÊN THẤP", recs_low)]:
        if not recs:
            continue
        lines += [f"  {priority_label}:", ""]
        for i, r in enumerate(recs, 1):
            lines += [f"  [{i}] {r.reason}"]
            if r.config_lines:
                lines.append("      -- Thêm/Sửa các dòng sau:")
                for line in r.config_lines:
                    lines.append(f"         {line}")
            if r.remove_lines:
                lines.append("      -- Xóa các dòng sau:")
                for line in r.remove_lines:
                    lines.append(f"         no {line}")
            lines.append("")

    lines += [SEP,
              "  Báo cáo tạo bởi NetAnalyzer — AI-powered Network Config Analyzer",
              SEP]

    return "\n".join(lines)


def analyze_from_text(config_text, hostname="device", vendor="cisco_ios", api_key=None):
    """Phân tích từ text config, không cần kết nối thiết bị."""
    from core.connector import DeviceConfig
    mock = DeviceConfig(
        hostname=hostname, ip="0.0.0.0",
        vendor=vendor, device_type=vendor,
        running_config=config_text, connected=True,
    )
    return AIConfigAnalyzer(api_key=api_key).analyze(mock)
