"""
NetAnalyzer - Database Layer
Lưu trữ toàn bộ config và kết quả phân tích vào SQLite
"""

import sqlite3
import json
import os
from datetime import datetime
from contextlib import contextmanager

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "netanalyzer.db")


def init_db():
    """Tạo database và các bảng nếu chưa có."""
    with get_conn() as conn:
        conn.executescript("""
        -- Thông tin thiết bị
        CREATE TABLE IF NOT EXISTS devices (
            id          TEXT PRIMARY KEY,
            hostname    TEXT,
            ip          TEXT NOT NULL,
            device_type TEXT,
            vendor      TEXT,
            port        INTEGER DEFAULT 22,
            created_at  TEXT,
            last_seen   TEXT
        );

        -- Mỗi lần scan = 1 bản ghi config
        CREATE TABLE IF NOT EXISTS config_snapshots (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id   TEXT NOT NULL,
            scanned_at  TEXT NOT NULL,
            running_config TEXT,
            raw_outputs TEXT,       -- JSON: {command: output, ...}
            FOREIGN KEY (device_id) REFERENCES devices(id)
        );

        -- Kết quả phân tích AI
        CREATE TABLE IF NOT EXISTS analysis_results (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            snapshot_id     INTEGER NOT NULL,
            device_id       TEXT NOT NULL,
            analyzed_at     TEXT NOT NULL,
            score           INTEGER,
            grade           TEXT,
            summary         TEXT,
            score_breakdown TEXT,   -- JSON
            findings        TEXT,   -- JSON array
            recommendations TEXT,   -- JSON array (config đề xuất)
            report_txt      TEXT,   -- Full text report
            FOREIGN KEY (snapshot_id) REFERENCES config_snapshots(id)
        );
        """)


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ── Devices ────────────────────────────────────────────────────────────────────

def upsert_device(device_id, hostname, ip, device_type, vendor="", port=22):
    now = datetime.now().isoformat()
    with get_conn() as conn:
        existing = conn.execute("SELECT id FROM devices WHERE id=?", (device_id,)).fetchone()
        if existing:
            conn.execute(
                "UPDATE devices SET hostname=?, ip=?, device_type=?, vendor=?, last_seen=? WHERE id=?",
                (hostname, ip, device_type, vendor, now, device_id)
            )
        else:
            conn.execute(
                "INSERT INTO devices (id,hostname,ip,device_type,vendor,port,created_at,last_seen) VALUES (?,?,?,?,?,?,?,?)",
                (device_id, hostname, ip, device_type, vendor, port, now, now)
            )


def get_all_devices():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM devices ORDER BY last_seen DESC").fetchall()
        return [dict(r) for r in rows]


def get_device(device_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM devices WHERE id=?", (device_id,)).fetchone()
        return dict(row) if row else None


def delete_device(device_id):
    with get_conn() as conn:
        conn.execute("DELETE FROM analysis_results WHERE device_id=?", (device_id,))
        conn.execute("DELETE FROM config_snapshots WHERE device_id=?", (device_id,))
        conn.execute("DELETE FROM devices WHERE id=?", (device_id,))


# ── Config Snapshots ───────────────────────────────────────────────────────────

def save_config_snapshot(device_id, running_config, raw_outputs: dict) -> int:
    """Lưu config snapshot, trả về snapshot_id."""
    now = datetime.now().isoformat()
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO config_snapshots (device_id, scanned_at, running_config, raw_outputs) VALUES (?,?,?,?)",
            (device_id, now, running_config, json.dumps(raw_outputs, ensure_ascii=False))
        )
        return cur.lastrowid


def get_latest_snapshot(device_id):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM config_snapshots WHERE device_id=? ORDER BY scanned_at DESC LIMIT 1",
            (device_id,)
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["raw_outputs"] = json.loads(d["raw_outputs"] or "{}")
        return d


def get_snapshot_history(device_id, limit=10):
    """Lịch sử các lần scan."""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id, device_id, scanned_at FROM config_snapshots WHERE device_id=? ORDER BY scanned_at DESC LIMIT ?",
            (device_id, limit)
        ).fetchall()
        return [dict(r) for r in rows]


# ── Analysis Results ───────────────────────────────────────────────────────────

def save_analysis(snapshot_id, device_id, result, report_txt=""):
    """Lưu kết quả phân tích AI."""
    now = datetime.now().isoformat()
    findings = [
        {
            "severity": f.severity,
            "category": f.category,
            "title": f.title,
            "description": f.description,
            "recommendation": f.recommendation,
            "commands": f.commands,
            "cis_reference": f.cis_reference,
            "status": f.status,
        }
        for f in result.findings
    ]
    recs = [
        {
            "priority": r.priority,
            "action": r.action,
            "reason": r.reason,
            "config_lines": r.config_lines,
            "remove_lines": r.remove_lines,
        }
        for r in result.recommendations
    ]
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO analysis_results
               (snapshot_id,device_id,analyzed_at,score,grade,summary,score_breakdown,findings,recommendations,report_txt)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (snapshot_id, device_id, now,
             result.score, result.grade, result.summary,
             json.dumps(result.score_breakdown, ensure_ascii=False),
             json.dumps(findings, ensure_ascii=False),
             json.dumps(recs, ensure_ascii=False),
             report_txt)
        )
        return cur.lastrowid


def get_latest_analysis(device_id):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM analysis_results WHERE device_id=? ORDER BY analyzed_at DESC LIMIT 1",
            (device_id,)
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["findings"] = json.loads(d["findings"] or "[]")
        d["recommendations"] = json.loads(d["recommendations"] or "[]")
        d["score_breakdown"] = json.loads(d["score_breakdown"] or "{}")
        return d


def get_analysis_history(device_id, limit=10):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id,device_id,analyzed_at,score,grade FROM analysis_results WHERE device_id=? ORDER BY analyzed_at DESC LIMIT ?",
            (device_id, limit)
        ).fetchall()
        return [dict(r) for r in rows]
