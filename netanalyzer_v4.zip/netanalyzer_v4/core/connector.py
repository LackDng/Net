"""
NetAnalyzer - Core Connector
Quản lý kết nối SSH/Telnet đến thiết bị mạng đa vendor
Hỗ trợ: Cisco IOS/IOS-XE/NX-OS, MikroTik, Juniper, HP/Aruba
"""

import logging
from dataclasses import dataclass, field
from typing import Optional
from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException

logger = logging.getLogger(__name__)


# ─── Map vendor string → netmiko device_type ──────────────────────────────────
VENDOR_MAP = {
    "cisco_ios":        "cisco_ios",
    "cisco_iosxe":      "cisco_ios",
    "cisco_nxos":       "cisco_nxos",
    "cisco_asa":        "cisco_asa",
    "cisco_xr":         "cisco_xr",
    "mikrotik":         "mikrotik_routeros",
    "mikrotik_routeros":"mikrotik_routeros",
    "juniper":          "juniper_junos",
    "juniper_junos":    "juniper_junos",
    "hp_comware":       "hp_comware",
    "hp_procurve":      "hp_procurve",
    "aruba":            "aruba_os",
    "autodetect":       "autodetect",
}

# ─── Commands per vendor ────────────────────────────────────────────────────────
SHOW_COMMANDS = {
    "cisco_ios": [
        "show running-config",
        "show version",
        "show interfaces",
        "show ip interface brief",
        "show spanning-tree",
        "show vlan brief",
        "show ip route summary",
        "show logging",
        "show ntp status",
        "show snmp",
        "show access-lists",
        "show crypto key mypubkey rsa",
        "show cdp neighbors detail",
    ],
    "cisco_nxos": [
        "show running-config",
        "show version",
        "show interface brief",
        "show vlan brief",
        "show spanning-tree",
        "show ip route summary",
        "show ntp peers",
        "show snmp",
        "show logging",
        "show cdp neighbors detail",
        "show feature",
    ],
    "mikrotik_routeros": [
        "/system identity print",
        "/system resource print",
        "/interface print",
        "/ip address print",
        "/ip firewall filter print",
        "/ip firewall nat print",
        "/system ntp client print",
        "/snmp print",
        "/user print",
        "/ip service print",
        "/routing ospf instance print",
        "/system logging print",
    ],
    "juniper_junos": [
        "show configuration",
        "show version",
        "show interfaces terse",
        "show route summary",
        "show spanning-tree interface",
        "show ntp associations",
        "show snmp",
        "show log messages | last 20",
    ],
    "hp_comware": [
        "display current-configuration",
        "display version",
        "display interface brief",
        "display vlan all",
        "display stp",
        "display ntp status",
        "display snmp-agent sys-info",
        "display logbuffer",
    ],
    "aruba_os": [
        "show running-config",
        "show version",
        "show interfaces",
        "show vlan",
        "show spanning-tree",
        "show ntp",
        "show snmp-server",
        "show logging",
    ],
}

# Fallback cho vendor không được map
SHOW_COMMANDS["cisco_xr"] = SHOW_COMMANDS["cisco_ios"]
SHOW_COMMANDS["cisco_asa"] = SHOW_COMMANDS["cisco_ios"]
SHOW_COMMANDS["hp_procurve"] = SHOW_COMMANDS["hp_comware"]


@dataclass
class DeviceConfig:
    """Kết quả sau khi đọc cấu hình từ thiết bị"""
    hostname: str
    ip: str
    vendor: str
    device_type: str
    version_info: str = ""
    raw_configs: dict = field(default_factory=dict)   # {command: output}
    running_config: str = ""
    error: Optional[str] = None
    connected: bool = False


@dataclass
class DeviceCredential:
    """Thông tin kết nối thiết bị"""
    ip: str
    username: str
    password: str
    device_type: str = "autodetect"
    port: int = 22
    secret: str = ""          # enable secret cho Cisco
    timeout: int = 30
    verbose: bool = False


class NetworkConnector:
    """
    Kết nối đến thiết bị mạng và thu thập cấu hình.
    
    Ví dụ sử dụng:
        cred = DeviceCredential(ip="192.168.1.1", username="admin", password="pass", device_type="cisco_ios")
        connector = NetworkConnector(cred)
        config = connector.collect_config()
    """

    def __init__(self, credential: DeviceCredential):
        self.cred = credential
        self.connection = None
        self._device_type = VENDOR_MAP.get(credential.device_type.lower(), credential.device_type)

    # ── Kết nối ────────────────────────────────────────────────────────────────
    def connect(self) -> bool:
        """Tạo SSH connection, trả về True nếu thành công."""
        device_params = {
            "device_type": self._device_type,
            "host":        self.cred.ip,
            "username":    self.cred.username,
            "password":    self.cred.password,
            "port":        self.cred.port,
            "secret":      self.cred.secret,
            "timeout":     self.cred.timeout,
            "verbose":     self.cred.verbose,
        }
        try:
            self.connection = ConnectHandler(**device_params)
            if self.cred.secret:
                self.connection.enable()
            logger.info(f"[+] Đã kết nối: {self.cred.ip}")
            return True
        except NetmikoTimeoutException:
            logger.error(f"[-] Timeout khi kết nối {self.cred.ip}")
        except NetmikoAuthenticationException:
            logger.error(f"[-] Sai credentials cho {self.cred.ip}")
        except Exception as e:
            logger.error(f"[-] Lỗi kết nối {self.cred.ip}: {e}")
        return False

    def disconnect(self):
        if self.connection:
            self.connection.disconnect()
            logger.info(f"[*] Đã ngắt kết nối: {self.cred.ip}")

    # ── Thu thập cấu hình ──────────────────────────────────────────────────────
    def collect_config(self) -> DeviceConfig:
        """
        Kết nối và chạy tất cả show commands phù hợp với vendor.
        Trả về DeviceConfig với đầy đủ raw output.
        """
        config = DeviceConfig(
            hostname="unknown",
            ip=self.cred.ip,
            vendor=self.cred.device_type,
            device_type=self._device_type,
        )

        if not self.connect():
            config.error = "Connection failed"
            return config

        try:
            config.connected = True

            # Lấy hostname
            config.hostname = self._get_hostname()

            # Lấy danh sách commands cho vendor này
            commands = self._get_commands_for_vendor()

            # Chạy từng command
            for cmd in commands:
                try:
                    output = self.connection.send_command(
                        cmd,
                        read_timeout=30,
                    )
                    config.raw_configs[cmd] = output
                    logger.debug(f"    ✓ {cmd}")
                except Exception as e:
                    config.raw_configs[cmd] = f"[ERROR: {e}]"
                    logger.warning(f"    ✗ {cmd}: {e}")

            # Gán running config riêng để tiện phân tích
            config.running_config = config.raw_configs.get(
                "show running-config",
                config.raw_configs.get("/export", "")
            )

            # Version info
            config.version_info = config.raw_configs.get(
                "show version",
                config.raw_configs.get("/system resource print", "")
            )

        except Exception as e:
            config.error = str(e)
            logger.error(f"[-] Lỗi thu thập config từ {self.cred.ip}: {e}")
        finally:
            self.disconnect()

        return config

    # ── Helpers ────────────────────────────────────────────────────────────────
    def _get_hostname(self) -> str:
        """Lấy hostname của thiết bị."""
        try:
            if "mikrotik" in self._device_type:
                out = self.connection.send_command("/system identity print")
                for line in out.splitlines():
                    if "name:" in line:
                        return line.split(":")[-1].strip()
            elif "juniper" in self._device_type:
                out = self.connection.send_command("show version | match Hostname")
                for line in out.splitlines():
                    if "Hostname" in line:
                        return line.split(":")[-1].strip()
            else:
                # Cisco và các thiết bị dùng prompt
                prompt = self.connection.find_prompt()
                return prompt.strip("#>").strip()
        except Exception:
            pass
        return self.cred.ip

    def _get_commands_for_vendor(self) -> list:
        """Trả về danh sách commands phù hợp với device type."""
        # Tìm exact match
        if self._device_type in SHOW_COMMANDS:
            return SHOW_COMMANDS[self._device_type]
        # Fuzzy match
        for key in SHOW_COMMANDS:
            if key in self._device_type or self._device_type in key:
                return SHOW_COMMANDS[key]
        # Fallback: dùng Cisco IOS commands
        logger.warning(f"Không tìm thấy commands cho {self._device_type}, dùng Cisco IOS fallback")
        return SHOW_COMMANDS["cisco_ios"]

    def test_connection(self) -> dict:
        """Kiểm tra kết nối nhanh, không thu thập config đầy đủ."""
        result = {"ip": self.cred.ip, "success": False, "hostname": None, "error": None}
        if self.connect():
            result["success"] = True
            result["hostname"] = self._get_hostname()
            self.disconnect()
        else:
            result["error"] = "Cannot connect — kiểm tra IP, credentials, hoặc firewall"
        return result
