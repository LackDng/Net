"""
NetAnalyzer - Core Connector v2
3-Phase: Probe (paramiko raw) → AI Identify → Collect (netmiko)
"""

import logging
import time
import paramiko
from dataclasses import dataclass, field
from typing import Optional, List

logger = logging.getLogger(__name__)


# ── Fallback commands (dùng khi AI identify thất bại) ─────────────────────────
FALLBACK_COMMANDS = {
    "cisco_ios": [
        "show running-config",
        "show version",
        "show interfaces",
        "show ip interface brief",
        "show spanning-tree",
        "show vlan brief",
        "show ip route",
        "show logging",
        "show ntp status",
        "show snmp",
        "show access-lists",
        "show cdp neighbors detail",
        "show crypto key mypubkey rsa",
    ],
    "cisco_nxos": [
        "show running-config",
        "show version",
        "show interface brief",
        "show vlan brief",
        "show spanning-tree",
        "show ip route",
        "show ntp peers",
        "show snmp",
        "show logging",
        "show cdp neighbors detail",
        "show feature",
        "show vpc",
    ],
    "cisco_asa": [
        "show running-config",
        "show version",
        "show interface",
        "show route",
        "show nat",
        "show access-list",
        "show crypto ikev1 sa",
        "show vpn-sessiondb summary",
        "show logging",
    ],
    "cisco_xr": [
        "show running-config",
        "show version",
        "show interfaces",
        "show ip route summary",
        "show bgp summary",
        "show mpls interfaces",
        "show logging",
    ],
    "mikrotik_routeros": [
        "/export",
        "/system identity print",
        "/system resource print",
        "/interface print detail",
        "/ip address print",
        "/ip firewall filter print",
        "/ip firewall nat print",
        "/ip firewall mangle print",
        "/system ntp client print",
        "/snmp print",
        "/user print",
        "/ip service print",
        "/routing ospf instance print",
        "/system logging print",
        "/certificate print",
    ],
    "juniper_junos": [
        "show configuration",
        "show version",
        "show interfaces terse",
        "show route summary",
        "show spanning-tree interface",
        "show ntp associations",
        "show snmp",
        "show log messages | last 50",
        "show bgp summary",
    ],
    "hp_comware": [
        "display current-configuration",
        "display version",
        "display interface brief",
        "display vlan all",
        "display stp",
        "display ntp status",
        "display snmp-agent sys-info",
        "display logbuffer",
        "display bgp peer",
    ],
    "hp_procurve": [
        "show running-config",
        "show version",
        "show interfaces",
        "show vlan",
        "show spanning-tree",
        "show ntp",
        "show snmp-server",
        "show logging",
    ],
    "aruba_os": [
        "show running-config",
        "show version",
        "show interfaces",
        "show vlan",
        "show spanning-tree",
        "show ntp",
        "show snmp-server",
        "show logging",
    ],
    "huawei_vrpv8": [
        "display current-configuration",
        "display version",
        "display interface brief",
        "display vlan",
        "display stp",
        "display ntp status",
        "display snmp-agent sys-info",
        "display logbuffer",
    ],
}

# Probe commands — thử lần lượt, an toàn với mọi thiết bị
PROBE_COMMANDS = [
    "show version",
    "display version",
    "/system resource print",
]


# ── Dataclasses ────────────────────────────────────────────────────────────────

@dataclass
class DeviceIdentity:
    """Kết quả nhận diện thiết bị từ AI."""
    vendor: str = ""                        # cisco, mikrotik, juniper, hp, huawei, ...
    model: str = ""                         # Catalyst 3850, CCR1036, MX480, ...
    os_version: str = ""                    # IOS-XE 16.9.4, RouterOS 7.11, ...
    netmiko_device_type: str = ""           # cisco_ios, mikrotik_routeros, ...
    commands: List[str] = field(default_factory=list)
    confidence: str = "low"                # high | medium | low
    detected_by: str = "ai"               # ai | manual | fallback
    reason: str = ""


@dataclass
class DeviceConfig:
    """Kết quả sau khi đọc cấu hình từ thiết bị."""
    hostname: str
    ip: str
    vendor: str
    device_type: str
    model: str = ""
    os_version: str = ""
    version_info: str = ""
    raw_configs: dict = field(default_factory=dict)   # {command: output}
    running_config: str = ""
    identity: Optional[DeviceIdentity] = None
    error: Optional[str] = None
    connected: bool = False


@dataclass
class DeviceCredential:
    """Thông tin kết nối thiết bị."""
    ip: str
    username: str
    password: str
    device_type: str = "autodetect"
    port: int = 22
    secret: str = ""
    timeout: int = 30
    verbose: bool = False
    # Override từ user khi AI detect sai
    vendor_override: str = ""
    model_override: str = ""


# ── Phase 1: Raw SSH Probe ─────────────────────────────────────────────────────

class DeviceProber:
    """
    Kết nối raw SSH bằng paramiko (không cần biết device type),
    lấy SSH banner + chạy probe commands để nhận diện thiết bị.
    """

    def __init__(self, ip: str, username: str, password: str,
                 port: int = 22, timeout: int = 15):
        self.ip = ip
        self.username = username
        self.password = password
        self.port = port
        self.timeout = timeout

    def probe(self) -> dict:
        """
        Returns:
            {
                "banner": str,
                "probe_output": str,   # greeting + outputs từ probe commands
                "error": str | None
            }
        """
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        probe_output = ""
        banner = ""

        try:
            ssh.connect(
                self.ip,
                port=self.port,
                username=self.username,
                password=self.password,
                timeout=self.timeout,
                look_for_keys=False,
                allow_agent=False,
            )

            transport = ssh.get_transport()
            raw_banner = transport.get_banner()
            banner = raw_banner.decode("utf-8", errors="replace") if raw_banner else ""

            # Mở interactive shell (raw terminal)
            shell = ssh.invoke_shell(width=220, height=50)
            time.sleep(2)

            # Lấy greeting/prompt ban đầu
            initial = self._recv(shell)
            if initial:
                probe_output += f"[GREETING]\n{initial}\n\n"

            # Thử từng probe command
            for cmd in PROBE_COMMANDS:
                try:
                    shell.send(cmd + "\n")
                    time.sleep(3)
                    out = self._recv(shell)
                    probe_output += f"[CMD: {cmd}]\n{out}\n\n"
                    # Nếu đã có output hữu ích, tiếp tục các lệnh còn lại
                except Exception:
                    pass

            logger.info(f"[PROBE] {self.ip}: {len(probe_output)} chars")
            return {"banner": banner, "probe_output": probe_output, "error": None}

        except paramiko.AuthenticationException:
            return {"banner": banner, "probe_output": "", "error": "Authentication failed"}
        except Exception as e:
            logger.error(f"[PROBE] {self.ip}: {e}")
            return {"banner": banner, "probe_output": probe_output, "error": str(e)}
        finally:
            try:
                ssh.close()
            except Exception:
                pass

    def _recv(self, shell, wait: float = 0.5, max_bytes: int = 8192) -> str:
        """Đọc output từ shell cho đến khi hết dữ liệu."""
        output = ""
        deadline = time.time() + 5
        while time.time() < deadline:
            if shell.recv_ready():
                chunk = shell.recv(max_bytes)
                output += chunk.decode("utf-8", errors="replace")
                time.sleep(wait)
            else:
                time.sleep(0.2)
                if not shell.recv_ready():
                    break
        return output


# ── Phase 3: Netmiko Collector ─────────────────────────────────────────────────

class NetworkConnector:
    """
    3-Phase connector:
      Phase 1 — DeviceProber: raw SSH probe
      Phase 2 — AI identify: gọi AI xác định vendor/model/commands
      Phase 3 — Netmiko collect: kết nối đúng device_type, chạy commands từ AI
    """

    def __init__(self, credential: DeviceCredential, api_key: str = ""):
        self.cred = credential
        self.api_key = api_key
        self.connection = None
        self.identity: Optional[DeviceIdentity] = None

    # ── Entry point ────────────────────────────────────────────────────────────

    def collect_config(self, progress_cb=None) -> DeviceConfig:
        """
        Chạy 3 phase, gọi progress_cb(message, percent) sau mỗi bước.
        """
        config = DeviceConfig(
            hostname="unknown",
            ip=self.cred.ip,
            vendor="unknown",
            device_type="unknown",
        )

        def _p(msg, pct):
            if progress_cb:
                progress_cb(msg, pct)
            logger.info(f"[{pct:3d}%] {msg}")

        # ── Phase 1: Probe ─────────────────────────────────────────────────────
        _p(f"Phase 1 — Probe raw SSH tới {self.cred.ip}...", 10)
        prober = DeviceProber(
            self.cred.ip, self.cred.username, self.cred.password,
            self.cred.port, self.cred.timeout,
        )
        probe = prober.probe()

        if probe["error"] and not probe["probe_output"] and not probe["banner"]:
            config.error = f"Không thể kết nối SSH: {probe['error']}"
            return config

        probe_text = (
            f"SSH Banner:\n{probe['banner']}\n\n"
            f"Probe Output:\n{probe['probe_output']}"
        )

        # ── Phase 2: AI Identify ───────────────────────────────────────────────
        _p("Phase 2 — AI đang nhận diện vendor / model / commands...", 25)
        identity = self._ai_identify(probe_text)
        self.identity = identity
        config.identity = identity

        logger.info(
            f"[IDENTIFY] vendor={identity.vendor!r} model={identity.model!r} "
            f"os={identity.os_version!r} dtype={identity.netmiko_device_type!r} "
            f"confidence={identity.confidence} by={identity.detected_by} "
            f"cmds={len(identity.commands)}"
        )

        _p(
            f"Đã nhận diện: {identity.vendor} {identity.model} "
            f"({identity.os_version}) — confidence={identity.confidence}",
            38,
        )

        # ── Phase 3: Collect via Netmiko ───────────────────────────────────────
        device_type = identity.netmiko_device_type or "cisco_ios"
        commands = identity.commands
        if not commands:
            commands = FALLBACK_COMMANDS.get(device_type, FALLBACK_COMMANDS["cisco_ios"])
            logger.warning(f"AI không trả về commands → fallback cho {device_type}")

        _p(f"Phase 3 — SSH ({device_type}) kết nối lại để thu thập...", 42)
        if not self._connect(device_type):
            config.error = "SSH kết nối thất bại ở phase 3 (collect)"
            return config

        try:
            config.connected = True
            config.vendor = identity.vendor
            config.model = identity.model
            config.os_version = identity.os_version
            config.device_type = device_type

            config.hostname = self._get_hostname(device_type)
            _p(f"Đọc {len(commands)} lệnh từ {config.hostname}...", 50)

            for i, cmd in enumerate(commands):
                pct = 50 + int((i / len(commands)) * 20)
                try:
                    out = self.connection.send_command(cmd, read_timeout=30)
                    config.raw_configs[cmd] = out
                    logger.debug(f"    ✓ {cmd}")
                except Exception as e:
                    config.raw_configs[cmd] = f"[ERROR: {e}]"
                    logger.warning(f"    ✗ {cmd}: {e}")

            # Gán running_config từ lệnh phổ biến nhất
            for key in (
                "show running-config",
                "/export",
                "show configuration",
                "display current-configuration",
            ):
                if key in config.raw_configs and "[ERROR" not in config.raw_configs[key]:
                    config.running_config = config.raw_configs[key]
                    break

            # Version info
            for key in ("show version", "/system resource print", "display version"):
                if key in config.raw_configs and "[ERROR" not in config.raw_configs[key]:
                    config.version_info = config.raw_configs[key]
                    break

        except Exception as e:
            config.error = str(e)
            logger.error(f"[-] Lỗi collect {self.cred.ip}: {e}")
        finally:
            self._disconnect()

        return config

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _ai_identify(self, probe_text: str) -> DeviceIdentity:
        """Gọi analyzer.identify_device_with_ai() với override từ user."""
        from core.analyzer import identify_device_with_ai
        return identify_device_with_ai(
            probe_text=probe_text,
            api_key=self.api_key,
            vendor_override=self.cred.vendor_override,
            model_override=self.cred.model_override,
        )

    def _connect(self, device_type: str) -> bool:
        from netmiko import (
            ConnectHandler,
            NetmikoTimeoutException,
            NetmikoAuthenticationException,
        )
        params = {
            "device_type": device_type,
            "host":        self.cred.ip,
            "username":    self.cred.username,
            "password":    self.cred.password,
            "port":        self.cred.port,
            "secret":      self.cred.secret,
            "timeout":     self.cred.timeout,
            "verbose":     self.cred.verbose,
        }
        try:
            self.connection = ConnectHandler(**params)
            if self.cred.secret:
                self.connection.enable()
            logger.info(f"[+] Kết nối netmiko OK: {self.cred.ip} ({device_type})")
            return True
        except NetmikoTimeoutException:
            logger.error(f"[-] Timeout: {self.cred.ip}")
        except NetmikoAuthenticationException:
            logger.error(f"[-] Auth failed: {self.cred.ip}")
        except Exception as e:
            logger.error(f"[-] Connect error ({device_type}): {e}")
        return False

    def _disconnect(self):
        if self.connection:
            try:
                self.connection.disconnect()
            except Exception:
                pass

    def _get_hostname(self, device_type: str) -> str:
        try:
            if "mikrotik" in device_type:
                out = self.connection.send_command("/system identity print")
                for line in out.splitlines():
                    if "name:" in line:
                        return line.split(":")[-1].strip()
            elif "juniper" in device_type:
                out = self.connection.send_command("show version | match Hostname")
                for line in out.splitlines():
                    if "Hostname" in line:
                        return line.split(":")[-1].strip()
            elif "huawei" in device_type or "comware" in device_type:
                out = self.connection.send_command("display version")
                for line in out.splitlines():
                    if "DEVICE" in line.upper() or "Huawei" in line:
                        return line.strip()
            else:
                return self.connection.find_prompt().strip("#>$").strip()
        except Exception:
            pass
        return self.cred.ip

    def test_connection(self) -> dict:
        """
        Test nhanh: chỉ probe, không collect đầy đủ.
        Trả về vendor/model nếu có API key.
        """
        result = {
            "ip": self.cred.ip,
            "success": False,
            "hostname": None,
            "vendor": None,
            "model": None,
            "os_version": None,
            "confidence": None,
            "error": None,
        }
        prober = DeviceProber(
            self.cred.ip, self.cred.username, self.cred.password,
            self.cred.port, timeout=10,
        )
        probe = prober.probe()

        if probe["error"] and not probe["probe_output"]:
            result["error"] = probe["error"]
            return result

        result["success"] = True

        if self.api_key:
            probe_text = (
                f"SSH Banner:\n{probe['banner']}\n\n"
                f"Probe Output:\n{probe['probe_output']}"
            )
            identity = self._ai_identify(probe_text)
            result["vendor"] = identity.vendor
            result["model"] = identity.model
            result["os_version"] = identity.os_version
            result["confidence"] = identity.confidence

        return result
