"""
NetAnalyzer v4 - Flask Web Server
Luồng: Kết nối → Đọc & Lưu config → Phân tích (đúng/sai/dư) → Đề xuất
"""

import os
import json
import uuid
import logging
import threading
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_socketio import SocketIO
from dotenv import load_dotenv

load_dotenv()

import sys
sys.path.insert(0, os.path.dirname(__file__))

from core.connector import NetworkConnector, DeviceCredential
from core.analyzer import AIConfigAnalyzer, generate_text_report
from core import database as db

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "netanalyzer-v4")
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="eventlet")

db.init_db()
logger.info("[DB] Database khởi tạo xong")

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
scan_status = {}   # {device_id: {stage, message, percent}}


# ── Helpers ────────────────────────────────────────────────────────────────────

def emit_progress(device_id, stage, message, percent):
    scan_status[device_id] = {"stage": stage, "message": message, "percent": percent}
    socketio.emit("scan_progress", {
        "device_id": device_id,
        "stage": stage, "message": message, "percent": percent,
        "timestamp": datetime.now().isoformat(),
    })
    logger.info(f"[{percent:3d}%] {device_id[:8]} — {message}")


# ── Background scan worker ─────────────────────────────────────────────────────

def run_scan(device_id, cred_data):
    try:
        # ── BƯỚC 1: Kết nối ───────────────────────────────────────────────────
        emit_progress(device_id, "connecting", f"Đang kết nối SSH tới {cred_data['ip']}...", 5)

        cred = DeviceCredential(
            ip=cred_data["ip"],
            username=cred_data["username"],
            password=cred_data["password"],
            device_type=cred_data.get("device_type", "cisco_ios"),
            port=int(cred_data.get("port", 22)),
            secret=cred_data.get("secret", ""),
        )
        connector = NetworkConnector(cred)

        # ── BƯỚC 2: Đọc toàn bộ config ────────────────────────────────────────
        emit_progress(device_id, "reading", "Đang đọc toàn bộ cấu hình thiết bị...", 20)
        device_config = connector.collect_config()

        if device_config.error:
            emit_progress(device_id, "error", f"Lỗi kết nối: {device_config.error}", 0)
            socketio.emit("scan_done", {"device_id": device_id, "error": device_config.error})
            scan_status.pop(device_id, None)
            return

        emit_progress(device_id, "reading",
                      f"Đã đọc {len(device_config.raw_configs)} lệnh từ {device_config.hostname}", 40)

        # ── BƯỚC 3: Lưu config vào database ───────────────────────────────────
        emit_progress(device_id, "saving", "Đang lưu cấu hình vào database...", 50)

        db.upsert_device(
            device_id=device_id,
            hostname=device_config.hostname,
            ip=device_config.ip,
            device_type=device_config.device_type,
            vendor=device_config.vendor,
            port=cred_data.get("port", 22),
        )

        snapshot_id = db.save_config_snapshot(
            device_id=device_id,
            running_config=device_config.running_config,
            raw_outputs=device_config.raw_configs,
        )

        emit_progress(device_id, "saved",
                      f"Đã lưu config snapshot #{snapshot_id} vào database", 55)

        # ── BƯỚC 4: Phân tích AI ───────────────────────────────────────────────
        emit_progress(device_id, "analyzing",
                      "Claude AI đang phân tích: đúng / sai / dư thừa...", 65)

        analyzer = AIConfigAnalyzer(api_key=ANTHROPIC_API_KEY)
        result = analyzer.analyze(device_config)

        if result.error:
            emit_progress(device_id, "error", f"Lỗi phân tích AI: {result.error}", 0)
            socketio.emit("scan_done", {"device_id": device_id, "error": result.error})
            scan_status.pop(device_id, None)
            return

        emit_progress(device_id, "analyzed",
                      f"Phân tích xong: {len(result.correct_findings)} đúng, "
                      f"{len(result.wrong_findings)} sai, "
                      f"{len(result.redundant_findings)} dư thừa", 85)

        # ── BƯỚC 5: Tạo report và lưu ─────────────────────────────────────────
        emit_progress(device_id, "reporting", "Đang tạo báo cáo...", 92)

        scanned_at = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        report_txt = generate_text_report(result, snapshot_time=scanned_at)

        db.save_analysis(
            snapshot_id=snapshot_id,
            device_id=device_id,
            result=result,
            report_txt=report_txt,
        )

        # ── BƯỚC 6: Xong ──────────────────────────────────────────────────────
        emit_progress(device_id, "done",
                      f"Hoàn thành! Score: {result.score}/100 ({result.grade})", 100)

        socketio.emit("scan_done", {
            "device_id": device_id,
            "result": db.get_latest_analysis(device_id),
        })
        scan_status.pop(device_id, None)

    except Exception as e:
        logger.error(f"[-] Scan failed {device_id}: {e}")
        emit_progress(device_id, "error", str(e), 0)
        socketio.emit("scan_done", {"device_id": device_id, "error": str(e)})
        scan_status.pop(device_id, None)


# ── REST API ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory("templates", "index.html")


# Config / settings
@app.route("/api/config", methods=["GET"])
def get_config():
    return jsonify({"api_key_set": bool(ANTHROPIC_API_KEY)})


@app.route("/api/config", methods=["POST"])
def set_config():
    global ANTHROPIC_API_KEY
    data = request.json or {}
    if "api_key" in data:
        ANTHROPIC_API_KEY = data["api_key"]
        os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY
    return jsonify({"success": True})


# Devices
@app.route("/api/devices", methods=["GET"])
def list_devices():
    devices = db.get_all_devices()
    # Gắn thêm analysis summary cho từng device
    for d in devices:
        analysis = db.get_latest_analysis(d["id"])
        d["score"] = analysis["score"] if analysis else None
        d["grade"] = analysis["grade"] if analysis else None
        d["status"] = "done" if analysis else ("scanning" if d["id"] in scan_status else "pending")
        d["critical_count"] = sum(
            1 for f in (analysis["findings"] if analysis else [])
            if f["severity"] == "critical" and f["status"] == "wrong"
        )
        d["wrong_count"] = sum(1 for f in (analysis["findings"] if analysis else []) if f["status"] == "wrong")
        d["redundant_count"] = sum(1 for f in (analysis["findings"] if analysis else []) if f["status"] == "redundant")
        if d["id"] in scan_status:
            d["status"] = "scanning"
            d["scan_progress"] = scan_status[d["id"]]
    return jsonify(devices)


@app.route("/api/devices", methods=["POST"])
def add_device():
    data = request.json or {}
    for f in ["ip", "username", "password"]:
        if not data.get(f):
            return jsonify({"error": f"Thiếu trường: {f}"}), 400

    device_id = str(uuid.uuid4())[:8]

    # Lưu device trước
    db.upsert_device(
        device_id=device_id,
        hostname=data.get("hostname") or data["ip"],
        ip=data["ip"],
        device_type=data.get("device_type", "cisco_ios"),
        port=int(data.get("port", 22)),
    )

    scan_status[device_id] = {"stage": "queued", "message": "Đang chờ...", "percent": 0}
    thread = threading.Thread(target=run_scan, args=(device_id, data), daemon=True)
    thread.start()

    return jsonify({"device_id": device_id, "message": "Đã bắt đầu scan"})


@app.route("/api/devices/<device_id>", methods=["DELETE"])
def delete_device(device_id):
    db.delete_device(device_id)
    scan_status.pop(device_id, None)
    return jsonify({"success": True})


# Analysis
@app.route("/api/analysis/<device_id>", methods=["GET"])
def get_analysis(device_id):
    result = db.get_latest_analysis(device_id)
    if not result:
        return jsonify({"error": "Chưa có kết quả phân tích"}), 404
    return jsonify(result)


@app.route("/api/analysis/<device_id>/history", methods=["GET"])
def get_analysis_history(device_id):
    return jsonify(db.get_analysis_history(device_id))


@app.route("/api/analysis/<device_id>/report", methods=["GET"])
def download_report(device_id):
    """Download báo cáo dạng .txt."""
    result = db.get_latest_analysis(device_id)
    if not result:
        return jsonify({"error": "Chưa có báo cáo"}), 404
    device = db.get_device(device_id)
    hostname = device["hostname"] if device else device_id
    from flask import Response
    return Response(
        result["report_txt"],
        mimetype="text/plain; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="report_{hostname}.txt"'}
    )


# Config snapshot
@app.route("/api/config-snapshot/<device_id>", methods=["GET"])
def get_config_snapshot(device_id):
    snap = db.get_latest_snapshot(device_id)
    if not snap:
        return jsonify({"error": "Chưa có config snapshot"}), 404
    return jsonify({
        "device_id": device_id,
        "scanned_at": snap["scanned_at"],
        "running_config": snap["running_config"],
    })


@app.route("/api/config-snapshot/<device_id>/history", methods=["GET"])
def get_snapshot_history(device_id):
    return jsonify(db.get_snapshot_history(device_id))


# Rescan
@app.route("/api/devices/<device_id>/rescan", methods=["POST"])
def rescan(device_id):
    data = request.json or {}
    if not data.get("ip"):
        device = db.get_device(device_id)
        if not device:
            return jsonify({"error": "Không tìm thấy thiết bị"}), 404
        data["ip"] = device["ip"]
        data["device_type"] = device.get("device_type", "cisco_ios")
    scan_status[device_id] = {"stage": "queued", "message": "Đang chờ...", "percent": 0}
    thread = threading.Thread(target=run_scan, args=(device_id, data), daemon=True)
    thread.start()
    return jsonify({"message": "Rescan đã bắt đầu"})


# Test connection
@app.route("/api/test-connection", methods=["POST"])
def test_connection():
    data = request.json or {}
    cred = DeviceCredential(
        ip=data.get("ip", ""),
        username=data.get("username", ""),
        password=data.get("password", ""),
        device_type=data.get("device_type", "cisco_ios"),
        port=int(data.get("port", 22)),
        timeout=10,
    )
    result = NetworkConnector(cred).test_connection()
    return jsonify(result)


# Analyze from paste text
@app.route("/api/analyze-text", methods=["POST"])
def analyze_text():
    data = request.json or {}
    config_text = data.get("config", "")
    if not config_text:
        return jsonify({"error": "Thiếu config text"}), 400

    from core.analyzer import analyze_from_text
    result = analyze_from_text(
        config_text=config_text,
        hostname=data.get("hostname", "paste-device"),
        vendor=data.get("vendor", "cisco_ios"),
        api_key=ANTHROPIC_API_KEY,
    )

    scanned_at = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    report_txt = generate_text_report(result, snapshot_time=scanned_at)

    findings = [
        {"severity": f.severity, "category": f.category, "status": f.status,
         "title": f.title, "description": f.description,
         "recommendation": f.recommendation, "commands": f.commands,
         "cis_reference": f.cis_reference}
        for f in result.findings
    ]
    recs = [
        {"priority": r.priority, "action": r.action, "reason": r.reason,
         "config_lines": r.config_lines, "remove_lines": r.remove_lines}
        for r in result.recommendations
    ]
    return jsonify({
        "hostname": result.hostname, "ip": result.ip, "vendor": result.vendor,
        "score": result.score, "grade": result.grade, "summary": result.summary,
        "score_breakdown": result.score_breakdown,
        "findings": findings, "recommendations": recs,
        "report_txt": report_txt, "error": result.error,
    })


# SocketIO
@socketio.on("connect")
def on_connect():
    logger.info(f"[WS] Connected: {request.sid}")


@socketio.on("disconnect")
def on_disconnect():
    logger.info(f"[WS] Disconnected: {request.sid}")


# ── Entry point ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"""
╔══════════════════════════════════════════╗
║     NetAnalyzer v4 - AI Config Analyzer  ║
╠══════════════════════════════════════════╣
║  URL : http://localhost:{port}              ║
║  DB  : netanalyzer.db (SQLite)           ║
╚══════════════════════════════════════════╝
    """)
    socketio.run(app, host="0.0.0.0", port=port, debug=False)
